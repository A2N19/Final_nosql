const mongoose = require("mongoose");
const bcrypt = require("bcrypt");
const User = require("./models/User"); // Убедись, что путь правильный

mongoose
  .connect("mongodb://localhost:27017/sportsShop", {
    useNewUrlParser: true,
    useUnifiedTopology: true,
  })
  .then(async () => {
    console.log("✅ MongoDB Connected");

    // Удаляем старого админа
    await User.deleteMany({ email: "a2n19a2n@gmail.com" });

    // Создаём нового админа
    const hashedPassword = await bcrypt.hash("123", 10);
    const admin = new User({
      username: "admin",
      email: "a2n19a2n@gmail.com",
      password: hashedPassword,
      role: "Admin",
    });

    await admin.save();
    console.log("✅ Admin created successfully!");

    mongoose.disconnect();
  });
