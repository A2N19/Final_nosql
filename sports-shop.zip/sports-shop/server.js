const express = require("express");
const dotenv = require("dotenv");
const cors = require("cors");
const cookieParser = require("cookie-parser");
const path = require("path");
const connectDB = require("./config/db");

dotenv.config();
connectDB();

const app = express();
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cors());
app.use(cookieParser());
app.use("/checkout", require("./routes/checkout"));

// ✅ Раздаём статические файлы (чтобы фото товаров отображались)
app.use("/images", express.static(path.join(__dirname, "public/images")));

// Главная страница
app.get("/", (req, res) => {
  res.send(`
        <html>
        <head>
            <title>Sports Shop API</title>
            <style>
                body { font-family: Arial, sans-serif; text-align: center; margin-top: 50px; }
                a { text-decoration: none; color: white; padding: 10px 20px; background: blue; border-radius: 5px; margin: 5px; display: inline-block; }
                a:hover { background: darkblue; }
            </style>
        </head>
        <body>
            <h1>Welcome to Sports Shop API</h1>
            <a href="/auth/login">Login</a>
            <a href="/auth/register">Register</a>
        </body>
        </html>
    `);
});

// Подключение маршрутов
app.use("/auth", require("./routes/auth"));
app.use("/products", require("./routes/products"));
app.use("/cart", require("./routes/cart"));

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`✅ Server running on port ${PORT}`));
