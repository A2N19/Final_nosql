const User = require("../models/User");
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
const nodemailer = require("nodemailer");

// ✅ Email configuration (Update with your credentials)
const transporter = nodemailer.createTransport({
  service: "gmail",
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASS,
  },
});

// ✅ Register a new user
exports.register = async (req, res) => {
  const { username, email, password } = req.body;

  // Check if email already exists
  const existingUser = await User.findOne({ email });
  if (existingUser) {
    return res.status(400).json({ error: "Email is already in use!" });
  }

  // Hash password
  const hashedPassword = await bcrypt.hash(password, 10);

  // Set role (first user is an admin)
  const isFirstUser = (await User.countDocuments()) === 0;
  const role = isFirstUser ? "Admin" : "User";

  // Create user
  const newUser = new User({ username, email, password: hashedPassword, role });
  await newUser.save();

  // ✅ Send welcome email
  const mailOptions = {
    from: process.env.EMAIL_USER,
    to: email,
    subject: "Welcome to Sports Shop!",
    text: `Hello, ${username}! 🎉 You have successfully registered on our store!`,
  };

  transporter.sendMail(mailOptions, (error) => {
    if (error) console.log("Email sending error:", error);
  });

  res.redirect("/products");
};

// ✅ User login
exports.login = async (req, res) => {
  const { email, password } = req.body;

  // Check if user exists
  const user = await User.findOne({ email });
  if (!user) {
    return res.status(401).json({ error: "User not found!" });
  }

  // Verify password
  const isPasswordValid = await bcrypt.compare(password, user.password);
  if (!isPasswordValid) {
    return res.status(401).json({ error: "Invalid password!" });
  }

  // Generate JWT token
  const token = jwt.sign(
    { userId: user._id, role: user.role },
    process.env.JWT_SECRET,
    { expiresIn: "1h" }
  );

  // Store token in cookies and redirect to the catalog
  res.cookie("token", token, { httpOnly: true });
  res.redirect("/products");
};

// ✅ User logout (clear cookies)
exports.logout = (req, res) => {
  res.clearCookie("token");
  res.redirect("/");
};

// ✅ Retrieve all users (Admins only)
exports.getAllUsers = async (req, res) => {
  try {
    const users = await User.find({}, "-password"); // Exclude passwords
    res.json(users);
  } catch (error) {
    res.status(500).json({ error: "Error fetching users" });
  }
};

// ✅ Send email after a successful order (called from checkout)
exports.sendOrderConfirmation = async (userId) => {
  const user = await User.findById(userId);
  if (!user) return;

  const mailOptions = {
    from: process.env.EMAIL_USER,
    to: user.email,
    subject: "✅ Your order has been placed!",
    text: `Thank you for your purchase, ${user.username}! Your order has been confirmed.`,
  };

  transporter.sendMail(mailOptions, (error) => {
    if (error) console.log("Email sending error:", error);
  });
};
