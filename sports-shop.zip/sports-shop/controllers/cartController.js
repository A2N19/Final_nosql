const Cart = require('../models/Cart');

exports.addToCart = async (req, res) => {
    const { productId, quantity } = req.body;
    let cart = await Cart.findOne({ userId: req.user.userId });

    if (!cart) {
        cart = new Cart({ userId: req.user.userId, products: [] });
    }

    cart.products.push({ productId, quantity });
    await cart.save();
    res.json({ message: 'Added to cart' });
};

exports.getCart = async (req, res) => {
    const cart = await Cart.findOne({ userId: req.user.userId }).populate('products.productId');
    res.json(cart);
};