const express = require("express");
const Cart = require("../models/Cart");
const User = require("../models/User");
const Order = require("../models/Order");
const { auth } = require("../middleware/authMiddleware");
const nodemailer = require("nodemailer");

const router = express.Router();

// ✅ Email setup (from .env)
const transporter = nodemailer.createTransport({
  service: "gmail",
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASS,
  },
});

// ✅ Order checkout page
router.get("/", auth, async (req, res) => {
  const userCart = await Cart.findOne({ userId: req.user.userId }).populate(
    "products.productId"
  );

  if (!userCart || userCart.products.length === 0) {
    return res.send(`
        <html>
        <head>
            <title>Checkout</title>
            <style>
                body { font-family: Arial, sans-serif; text-align: center; background: #f4f4f4; }
                .container { max-width: 600px; margin: auto; padding: 20px; background: white; border-radius: 10px; box-shadow: 0px 0px 10px rgba(0,0,0,0.1); }
                h1 { color: #333; }
                .btn { text-decoration: none; color: white; padding: 10px 20px; background: blue; border-radius: 5px; display: inline-block; margin-top: 10px; }
                .btn:hover { background: darkblue; }
            </style>
        </head>
        <body>
            <div class="container">
                <h1>❌ Your cart is empty!</h1>
                <a href='/products' class="btn">🔙 Return to catalog</a>
            </div>
        </body>
        </html>
    `);
  }

  let total = userCart.products.reduce(
    (sum, item) => sum + item.productId.price * item.quantity,
    0
  );

  res.send(`
        <html>
        <head>
            <title>Checkout</title>
            <style>
                body { font-family: Arial, sans-serif; text-align: center; background: #f4f4f4; }
                .container { max-width: 600px; margin: auto; padding: 20px; background: white; border-radius: 10px; box-shadow: 0px 0px 10px rgba(0,0,0,0.1); }
                .checkout-btn { background: green; color: white; padding: 10px 20px; border-radius: 5px; text-decoration: none; display: inline-block; margin-top: 10px; }
                .checkout-btn:hover { background: darkgreen; }
            </style>
        </head>
        <body>
            <div class="container">
                <h1>🛒 Checkout</h1>
                <p>Total Amount: <strong>${total} ₸</strong></p>
                <form action="/checkout/confirm" method="POST">
                    <button type="submit" class="checkout-btn">✅ Pay</button>
                </form>
            </div>
        </body>
        </html>
    `);
});

// ✅ Order Confirmation (Save Order to MongoDB)
router.post("/confirm", auth, async (req, res) => {
  console.log("✅ Order confirmation started...");

  const user = await User.findById(req.user.userId);
  if (!user) return res.status(404).json({ error: "User not found!" });

  const userCart = await Cart.findOne({ userId: req.user.userId }).populate(
    "products.productId"
  );

  if (!userCart || userCart.products.length === 0) {
    return res.status(400).json({ error: "Cart is empty!" });
  }

  let total = userCart.products.reduce(
    (sum, item) => sum + item.productId.price * item.quantity,
    0
  );

  console.log("📦 Order items:", userCart.products);

  const newOrder = new Order({
    userId: req.user.userId,
    products: userCart.products.map((p) => ({
      productId: p.productId ? p.productId._id : null, // Handle missing products
      quantity: p.quantity,
    })),
    total,
  });

  await newOrder.save();
  await Cart.deleteOne({ userId: req.user.userId });

  const mailOptions = {
    from: process.env.EMAIL_USER,
    to: user.email,
    subject: "✅ Your Order Has Been Placed!",
    text: `Thank you for your purchase, ${user.username}! Your order total is ${total} ₸.`,
  };

  transporter.sendMail(mailOptions, (error) => {
    if (error) console.log("❌ Email sending error:", error);
  });

  res.redirect("/checkout/history");
});

// ✅ View Order History (GET /checkout/history)
router.get("/history", auth, async (req, res) => {
  const orders = await Order.find({ userId: req.user.userId }).populate(
    "products.productId"
  );

  if (!orders.length) {
    return res.send(`
        <html>
        <head><title>My Orders</title></head>
        <body style="text-align: center; font-family: Arial;">
            <h1>❌ You have no orders yet!</h1>
            <a href='/products' class="btn">🔙 Return to Catalog</a>
        </body>
        </html>
    `);
  }

  let orderList = orders
    .map(
      (order) => `
        <div class="order">
            <h3>Order from ${order.createdAt.toLocaleString()}</h3>
            <p><strong>Status:</strong> ${order.status}</p>
            <p><strong>Total Amount:</strong> ${order.total} ₸</p>
            <ul>
                ${order.products
                  .map(
                    (p) =>
                      `<li>${
                        p.productId
                          ? `${p.productId.name} x${p.quantity} - ${
                              p.productId.price * p.quantity
                            } ₸`
                          : "❌ Product No Longer Available"
                      }</li>`
                  )
                  .join("")}
            </ul>
        </div>
    `
    )
    .join("");

  res.send(`
        <html>
        <head>
            <title>My Orders</title>
            <style>
                body { font-family: Arial, sans-serif; text-align: center; background: #f9f9f9; }
                .container { max-width: 800px; margin: auto; padding: 20px; background: white; border-radius: 10px; box-shadow: 0px 0px 10px rgba(0,0,0,0.1); }
                .order { border-bottom: 1px solid #ddd; padding: 15px; }
                .btn { background: blue; color: white; padding: 10px 20px; border-radius: 5px; text-decoration: none; }
                .btn:hover { background: darkblue; }
            </style>
        </head>
        <body>
            <div class="container">
                <h1>📦 Purchase History</h1>
                ${orderList}
                <a href="/products" class="btn">🔙 Return to Catalog</a>
            </div>
        </body>
        </html>
    `);
});

module.exports = router;
