const express = require("express");
const { register, login } = require("../controllers/authController");

const router = express.Router();

// Страница логина (GET /auth/login)
router.get("/login", (req, res) => {
  res.send(`
        <html>
        <head>
            <title>Login</title>
            <style>
                body { font-family: Arial, sans-serif; background: #f4f4f4; text-align: center; }
                .container { width: 300px; margin: 100px auto; padding: 20px; background: white; border-radius: 10px; box-shadow: 0px 0px 10px rgba(0,0,0,0.1); }
                input { width: 90%; padding: 10px; margin: 10px 0; border: 1px solid #ddd; border-radius: 5px; }
                button { background: blue; color: white; padding: 10px; border: none; border-radius: 5px; width: 100%; }
                button:hover { background: darkblue; cursor: pointer; }
            </style>
        </head>
        <body>
            <div class="container">
                <h2>Login</h2>
                <form action="/auth/login" method="POST">
                    <input type="email" name="email" placeholder="Email" required />
                    <input type="password" name="password" placeholder="Password" required />
                    <button type="submit">Login</button>
                </form>
            </div>
        </body>
        </html>
    `);
});

// Страница регистрации (GET /auth/register)
router.get("/register", (req, res) => {
  res.send(`
        <html>
        <head>
            <title>Register</title>
            <style>
                body { font-family: Arial, sans-serif; background: #f4f4f4; text-align: center; }
                .container { width: 300px; margin: 100px auto; padding: 20px; background: white; border-radius: 10px; box-shadow: 0px 0px 10px rgba(0,0,0,0.1); }
                input { width: 90%; padding: 10px; margin: 10px 0; border: 1px solid #ddd; border-radius: 5px; }
                button { background: blue; color: white; padding: 10px; border: none; border-radius: 5px; width: 100%; }
                button:hover { background: darkblue; cursor: pointer; }
            </style>
        </head>
        <body>
            <div class="container">
                <h2>Register</h2>
                <form action="/auth/register" method="POST">
                    <input type="text" name="username" placeholder="Username" required />
                    <input type="email" name="email" placeholder="Email" required />
                    <input type="password" name="password" placeholder="Password" required />
                    <button type="submit">Register</button>
                </form>
            </div>
        </body>
        </html>
    `);
});

// Обработчики POST-запросов
router.post("/register", register);
router.post("/login", login);

module.exports = router;
