const express = require("express");
const Cart = require("../models/Cart");
const Product = require("../models/Product");
const { auth } = require("../middleware/authMiddleware");

const router = express.Router();

// ✅ Add product to cart (GET /cart/add/:id)
router.get("/add/:id", auth, async (req, res) => {
  const userId = req.user.userId;
  const product = await Product.findById(req.params.id);

  if (!product) {
    return res.status(404).json({ error: "Product not found" });
  }

  let userCart = await Cart.findOne({ userId });

  if (!userCart) {
    userCart = new Cart({ userId, products: [] });
  }

  // Check if the product is already in the cart
  const existingProductIndex = userCart.products.findIndex((p) =>
    p.productId.equals(product._id)
  );

  if (existingProductIndex !== -1) {
    userCart.products[existingProductIndex].quantity += 1;
  } else {
    userCart.products.push({ productId: product._id, quantity: 1 });
  }

  await userCart.save();
  res.redirect("/cart");
});

// ✅ View Cart (GET /cart)
router.get("/", auth, async (req, res) => {
  const userCart = await Cart.findOne({ userId: req.user.userId }).populate(
    "products.productId"
  );

  if (!userCart || userCart.products.length === 0) {
    return res.send(`
        <html>
        <head>
            <title>Cart</title>
            <style>
                body { font-family: Arial, sans-serif; text-align: center; background: #f4f4f4; }
                .container { max-width: 600px; margin: auto; padding: 20px; background: white; border-radius: 10px; box-shadow: 0px 0px 10px rgba(0,0,0,0.1); }
                h1 { color: #333; }
                .btn { text-decoration: none; color: white; padding: 10px 20px; background: blue; border-radius: 5px; display: inline-block; margin-top: 10px; }
                .btn:hover { background: darkblue; }
            </style>
        </head>
        <body>
            <div class="container">
                <h1>❌ Your cart is empty!</h1>
                <a href='/products' class="btn">🔙 Return to catalog</a>
            </div>
        </body>
        </html>
    `);
  }

  let total = userCart.products.reduce(
    (sum, item) =>
      item.productId ? sum + item.productId.price * item.quantity : sum,
    0
  );

  let cartList = userCart.products
    .map(
      (p) => `
            <div class="product">
                <img src="/images/${
                  p.productId?.image || "default.png"
                }" width="100"/>
                <h3>${p.productId?.name || "❌ Product Removed"}</h3>
                <p>Quantity: ${p.quantity}</p>
                <p><strong>Price:</strong> ${
                  p.productId ? p.productId.price * p.quantity : "N/A"
                } ₸</p>
                <a href="/cart/remove/${
                  p.productId?._id
                }" class="remove">❌ Remove</a>
            </div>
        `
    )
    .join("");

  res.send(`
        <html>
        <head>
            <title>Cart</title>
            <style>
                body { font-family: Arial, sans-serif; text-align: center; background: #f4f4f4; }
                .container { max-width: 600px; margin: auto; padding: 20px; background: white; border-radius: 10px; box-shadow: 0px 0px 10px rgba(0,0,0,0.1); }
                .checkout-btn { background: green; color: white; padding: 10px 20px; border-radius: 5px; text-decoration: none; display: inline-block; margin-top: 10px; }
                .checkout-btn:hover { background: darkgreen; }
                .remove { color: red; text-decoration: none; }
                .remove:hover { color: darkred; }
            </style>
        </head>
        <body>
            <div class="container">
                <h1>🛒 Your Cart</h1>
                ${cartList}
                <h3>Total Amount: ${total} ₸</h3>
                <a href="/checkout" class="checkout-btn">✅ Proceed to Checkout</a>
            </div>
        </body>
        </html>
    `);
});

// ✅ Remove product from cart (GET /cart/remove/:id)
router.get("/remove/:id", auth, async (req, res) => {
  const userCart = await Cart.findOne({ userId: req.user.userId });

  if (userCart) {
    userCart.products = userCart.products.filter(
      (p) => p.productId && !p.productId.equals(req.params.id)
    );
    await userCart.save();
  }

  res.redirect("/cart");
});

module.exports = router;
