const express = require("express");
const multer = require("multer");
const Product = require("../models/Product");
const { auth, isAdmin } = require("../middleware/authMiddleware");
const path = require("path");
const jwt = require("jsonwebtoken");

const router = express.Router();

// ✅ Image Storage Setup
const storage = multer.diskStorage({
  destination: "./public/images/",
  filename: (req, file, cb) => {
    cb(
      null,
      file.fieldname + "-" + Date.now() + path.extname(file.originalname)
    );
  },
});

const upload = multer({ storage });

// ✅ Product Catalog (Visible to all)
router.get("/", async (req, res) => {
  const token = req.cookies?.token || req.headers.authorization?.split(" ")[1];
  const { search, category, minPrice, maxPrice } = req.query;

  let isAdmin = false;
  let isLoggedIn = false;
  if (token) {
    try {
      const decoded = jwt.verify(token, process.env.JWT_SECRET);
      isAdmin = decoded.role === "Admin";
      isLoggedIn = true;
    } catch (error) {
      console.log("Invalid token:", error.message);
    }
  }

  // ✅ Filtering options
  let filter = {};
  if (search) filter.name = new RegExp(search, "i");
  if (category) filter.category = category;
  if (minPrice || maxPrice) filter.price = {};
  if (minPrice) filter.price.$gte = parseFloat(minPrice);
  if (maxPrice) filter.price.$lte = parseFloat(maxPrice);

  const products = await Product.find(filter);

  let productList = products
    .map(
      (p) => `
        <div class="product">
            <img src="/images/${p.image}" width="150"/>
            <h3>${p.name}</h3>
            <p>${p.description}</p>
            <p><strong>Price:</strong> ${p.price} ₸</p>
            <a href="/cart/add/${p._id}" class="add-cart-btn">🛒 Add to Cart</a>
            ${
              isAdmin
                ? `<br>
                   <a href="/products/edit/${p._id}" class="edit-btn">✏ Edit</a>
                   <a href="/products/delete/${p._id}" class="delete-btn">❌ Delete</a>`
                : ""
            }
        </div>
    `
    )
    .join("");

  res.send(`
        <html>
        <head>
            <title>Product Catalog</title>
            <style>
                body { font-family: Arial, sans-serif; text-align: center; background: #f4f4f4; }
                .container { max-width: 900px; margin: auto; padding: 20px; background: white; border-radius: 10px; box-shadow: 0px 0px 10px rgba(0,0,0,0.1); }
                .product { border: 1px solid #ddd; padding: 10px; margin: 10px; display: inline-block; width: 250px; text-align: center; }
                .edit-btn, .delete-btn, .add-cart-btn, .history-btn { display: inline-block; padding: 5px 10px; margin: 5px; text-decoration: none; border-radius: 5px; }
                .edit-btn { background: orange; color: white; }
                .delete-btn { background: red; color: white; }
                .add-cart-btn { background: green; color: white; }
                .history-btn { background: blue; color: white; }
                .history-btn:hover { background: navy; }
            </style>
        </head>
        <body>
            <div class="container">
                <h1>Product Catalog</h1>
                <form method="GET">
                    <input type="text" name="search" placeholder="Search by name">
                    <input type="text" name="category" placeholder="Category">
                    <input type="number" name="minPrice" placeholder="Min price">
                    <input type="number" name="maxPrice" placeholder="Max price">
                    <button type="submit">🔍 Search</button>
                </form>
                ${productList}
                <div class="admin-panel">
                    ${
                      isAdmin
                        ? '<a href="/products/add" class="history-btn">➕ Add Product</a>'
                        : ""
                    }
                </div>
                ${
                  isLoggedIn
                    ? '<a href="/checkout/history" class="history-btn">📜 View Purchase History</a>'
                    : ""
                }
            </div>
        </body>
        </html>
    `);
});

// ✅ Add Product Page (Admins Only)
router.get("/add", auth, isAdmin, (req, res) => {
  res.send(`
          <html>
          <head>
              <title>Add Product</title>
              <style>
                  body { font-family: Arial, sans-serif; background: #f4f4f4; text-align: center; }
                  .container { max-width: 500px; margin: auto; background: white; padding: 20px; border-radius: 10px; box-shadow: 0px 0px 10px rgba(0,0,0,0.1); margin-top: 50px; }
                  input, textarea, select { width: 90%; padding: 10px; margin: 10px 0; border: 1px solid #ddd; border-radius: 5px; display: block; }
                  button { background: green; color: white; padding: 10px; border: none; border-radius: 5px; width: 100%; cursor: pointer; }
                  button:hover { background: darkgreen; }
                  .back-btn { background: gray; display: block; text-decoration: none; padding: 10px; color: white; margin-top: 10px; border-radius: 5px; }
              </style>
          </head>
          <body>
              <div class="container">
                  <h2>Add New Product</h2>
                  <form action="/products/add" method="POST" enctype="multipart/form-data">
                      <input type="text" name="name" placeholder="Product Name" required />
                      <input type="text" name="category" placeholder="Category" required />
                      <textarea name="description" placeholder="Description" required></textarea>
                      <input type="number" name="price" placeholder="Price (₸)" required />
                      <input type="file" name="image" required />
                      <button type="submit">Add Product</button>
                  </form>
                  <a href="/products" class="back-btn">🔙 Back to Catalog</a>
              </div>
          </body>
          </html>
      `);
});

// ✅ Handle Product Addition
router.post("/add", auth, isAdmin, upload.single("image"), async (req, res) => {
  try {
    const { name, category, description, price } = req.body;
    const image = req.file ? req.file.filename : "default.png";

    const newProduct = new Product({
      name,
      category,
      description,
      price,
      image,
    });
    await newProduct.save();
    res.redirect("/products");
  } catch (error) {
    res.status(500).json({ error: "Error adding product" });
  }
});

// ✅ Edit Product Page (Admins Only)
router.get("/edit/:id", auth, isAdmin, async (req, res) => {
  const product = await Product.findById(req.params.id);
  if (!product) return res.status(404).json({ error: "Product not found" });

  res.send(`
          <html>
          <head>
              <title>Edit Product</title>
              <style>
                  body { font-family: Arial, sans-serif; background: #f4f4f4; text-align: center; }
                  .container { max-width: 500px; margin: auto; background: white; padding: 20px; border-radius: 10px; box-shadow: 0px 0px 10px rgba(0,0,0,0.1); margin-top: 50px; }
                  input, textarea { width: 90%; padding: 10px; margin: 10px 0; border: 1px solid #ddd; border-radius: 5px; display: block; }
                  button { background: orange; color: white; padding: 10px; border: none; border-radius: 5px; width: 100%; cursor: pointer; }
                  button:hover { background: darkorange; }
                  .back-btn { background: gray; display: block; text-decoration: none; padding: 10px; color: white; margin-top: 10px; border-radius: 5px; }
              </style>
          </head>
          <body>
              <div class="container">
                  <h2>Edit Product</h2>
                  <form action="/products/edit/${product._id}" method="POST">
                      <input type="text" name="name" value="${product.name}" required />
                      <input type="text" name="category" value="${product.category}" required />
                      <textarea name="description" required>${product.description}</textarea>
                      <input type="number" name="price" value="${product.price}" required />
                      <button type="submit">Update Product</button>
                  </form>
                  <a href="/products" class="back-btn">🔙 Back to Catalog</a>
              </div>
          </body>
          </html>
      `);
});

// ✅ Handle Product Update
router.post("/edit/:id", auth, isAdmin, async (req, res) => {
  try {
    const { name, category, description, price } = req.body;
    await Product.findByIdAndUpdate(req.params.id, {
      name,
      category,
      description,
      price,
    });
    res.redirect("/products");
  } catch (error) {
    res.status(500).json({ error: "Error updating product" });
  }
});

// ✅ Delete Product (Admins Only)
router.get("/delete/:id", auth, isAdmin, async (req, res) => {
  try {
    await Product.findByIdAndDelete(req.params.id);
    res.redirect("/products");
  } catch (error) {
    res.status(500).json({ error: "Error deleting product" });
  }
});

module.exports = router;
