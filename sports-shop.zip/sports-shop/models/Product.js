const mongoose = require("mongoose");

const ProductSchema = new mongoose.Schema({
  name: { type: String, required: true, index: true }, // 🔍 Индекс для быстрого поиска по названию
  description: { type: String, required: true },
  category: { type: String, required: true, index: true }, // 🔍 Индекс для быстрого фильтра по категориям
  price: { type: Number, required: true, index: true }, // 🔍 Индекс для сортировки по цене
  image: { type: String, default: "default.png" },
});

// Создаём композитный индекс для быстрого поиска по `name` и `category`
ProductSchema.index({ name: 1, category: 1 });

module.exports = mongoose.model("Product", ProductSchema);
