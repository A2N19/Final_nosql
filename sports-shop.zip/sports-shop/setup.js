const fs = require("fs");
const path = require("path");

const folders = ["config", "models", "routes", "middleware", "controllers"];

const files = {
  "config/db.js": `const mongoose = require('mongoose');
require('dotenv').config();

const connectDB = async () => {
    try {
        await mongoose.connect(process.env.MONGO_URI, {
            useNewUrlParser: true,
            useUnifiedTopology: true,
        });
        console.log("MongoDB Connected");
    } catch (err) {
        console.error(err);
        process.exit(1);
    }
};

module.exports = connectDB;`,

  "models/User.js": `const mongoose = require('mongoose');

const UserSchema = new mongoose.Schema({
    username: String,
    password: String,
    role: { type: String, enum: ['User', 'Admin'], default: 'User' }
});

module.exports = mongoose.model('User', UserSchema);`,

  "models/Product.js": `const mongoose = require('mongoose');

const ProductSchema = new mongoose.Schema({
    name: String,
    description: String,
    price: Number,
    category: String,
    image: String
});

module.exports = mongoose.model('Product', ProductSchema);`,

  "models/Cart.js": `const mongoose = require('mongoose');

const CartSchema = new mongoose.Schema({
    userId: mongoose.Schema.Types.ObjectId,
    products: [{ productId: mongoose.Schema.Types.ObjectId, quantity: Number }]
});

module.exports = mongoose.model('Cart', CartSchema);`,

  "middleware/authMiddleware.js": `const jwt = require('jsonwebtoken');

const auth = (req, res, next) => {
    const token = req.headers.authorization;
    if (!token) return res.status(401).json({ error: 'Access denied' });

    jwt.verify(token, process.env.JWT_SECRET, (err, decoded) => {
        if (err) return res.status(403).json({ error: 'Invalid token' });

        req.user = decoded;
        next();
    });
};

module.exports = auth;`,

  "controllers/authController.js": `const User = require('../models/User');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');

exports.register = async (req, res) => {
    const { username, password } = req.body;
    const hashedPassword = await bcrypt.hash(password, 10);
    const newUser = new User({ username, password: hashedPassword });

    await newUser.save();
    res.json({ message: 'User registered' });
};

exports.login = async (req, res) => {
    const { username, password } = req.body;
    const user = await User.findOne({ username });

    if (!user || !await bcrypt.compare(password, user.password)) {
        return res.status(401).json({ error: 'Invalid credentials' });
    }

    const token = jwt.sign({ userId: user._id, role: user.role }, process.env.JWT_SECRET, { expiresIn: '1h' });
    res.json({ token });
};`,

  "controllers/productController.js": `const Product = require('../models/Product');

exports.getAllProducts = async (req, res) => {
    const products = await Product.find();
    res.json(products);
};

exports.createProduct = async (req, res) => {
    if (req.user.role !== 'Admin') return res.status(403).json({ error: 'Forbidden' });

    const newProduct = new Product(req.body);
    await newProduct.save();
    res.json({ message: 'Product added' });
};`,

  "controllers/cartController.js": `const Cart = require('../models/Cart');

exports.addToCart = async (req, res) => {
    const { productId, quantity } = req.body;
    let cart = await Cart.findOne({ userId: req.user.userId });

    if (!cart) {
        cart = new Cart({ userId: req.user.userId, products: [] });
    }

    cart.products.push({ productId, quantity });
    await cart.save();
    res.json({ message: 'Added to cart' });
};

exports.getCart = async (req, res) => {
    const cart = await Cart.findOne({ userId: req.user.userId }).populate('products.productId');
    res.json(cart);
};`,

  "routes/auth.js": `const express = require('express');
const { register, login } = require('../controllers/authController');

const router = express.Router();

router.post('/register', register);
router.post('/login', login);

module.exports = router;`,

  "routes/products.js": `const express = require('express');
const { getAllProducts, createProduct } = require('../controllers/productController');
const auth = require('../middleware/authMiddleware');

const router = express.Router();

router.get('/', getAllProducts);
router.post('/', auth, createProduct);

module.exports = router;`,

  "routes/cart.js": `const express = require('express');
const { addToCart, getCart } = require('../controllers/cartController');
const auth = require('../middleware/authMiddleware');

const router = express.Router();

router.post('/', auth, addToCart);
router.get('/', auth, getCart);

module.exports = router;`,

  "server.js": `const express = require('express');
const dotenv = require('dotenv');
const connectDB = require('./config/db');

dotenv.config();
connectDB();

const app = express();
app.use(express.json());

app.use('/auth', require('./routes/auth'));
app.use('/products', require('./routes/products'));
app.use('/cart', require('./routes/cart'));

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(\`Server running on port \${PORT}\`));`,

  ".env": `MONGO_URI=your_mongodb_connection_string
JWT_SECRET=your_secret_key
PORT=5000`,

  "package.json": `{
  "name": "sports-store-api",
  "version": "1.0.0",
  "description": "REST API for sports store",
  "main": "server.js",
  "scripts": {
    "start": "node server.js",
    "dev": "nodemon server.js"
  },
  "dependencies": {
    "express": "^4.18.2",
    "mongoose": "^6.7.0",
    "dotenv": "^16.0.3",
    "jsonwebtoken": "^9.0.0",
    "bcrypt": "^5.1.0",
    "cors": "^2.8.5"
  }
}`,
};

// Функция создания структуры проекта
const createStructure = () => {
  folders.forEach((folder) => {
    if (!fs.existsSync(folder)) {
      fs.mkdirSync(folder, { recursive: true });
      console.log(`📁 Создана папка: ${folder}`);
    }
  });

  Object.keys(files).forEach((filePath) => {
    const fullPath = path.join(__dirname, filePath);
    if (!fs.existsSync(fullPath)) {
      fs.writeFileSync(fullPath, files[filePath]);
      console.log(`📄 Создан файл: ${filePath}`);
    }
  });

  console.log("✅ Проект успешно создан!");
};

// Запуск скрипта
createStructure();
